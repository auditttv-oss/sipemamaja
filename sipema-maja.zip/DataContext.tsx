import React, { createContext, useContext, useState, ReactNode } from 'react';
import { 
  MOCK_COMPLAINTS, 
  MOCK_UNITS, 
  MOCK_INVOICES, 
  MOCK_CLUSTER_EXPENSES,
  MOCK_CLUSTERS,
  MOCK_VENDORS,
  MOCK_LEADS
} from './constants';
import { 
  Complaint, 
  UnitData, 
  Invoice, 
  ClusterExpense, 
  ComplaintStatus, 
  InvoiceStatus,
  Cluster,
  Vendor,
  Lead
} from './types';

interface DataContextType {
  complaints: Complaint[];
  units: UnitData[];
  invoices: Invoice[];
  expenses: ClusterExpense[];
  clusters: Cluster[]; 
  vendors: Vendor[];
  leads: Lead[];
  
  // Complaint CRUD
  addComplaint: (complaint: Complaint) => void;
  updateComplaintStatus: (id: string, status: ComplaintStatus) => void;
  
  // Unit CRUD
  addUnit: (unit: UnitData) => void;
  updateUnit: (unit: UnitData) => void;
  deleteUnit: (id: string) => void;
  
  // Invoice CRUD
  payInvoice: (id: string) => void;
  addInvoice: (invoice: Invoice) => void;
  updateInvoice: (invoice: Invoice) => void;
  deleteInvoice: (id: string) => void;
  
  // Expense CRUD
  addExpense: (expense: ClusterExpense) => void;
  updateExpense: (expense: ClusterExpense) => void;
  deleteExpense: (id: string) => void;
  
  // Cluster CRUD
  addCluster: (cluster: Cluster) => void;
  updateCluster: (cluster: Cluster) => void;
  deleteCluster: (id: string) => void;

  // Vendor CRUD
  addVendor: (vendor: Vendor) => void;
  updateVendor: (vendor: Vendor) => void;
  deleteVendor: (id: string) => void;

  // Marketing/Leads CRUD
  addLead: (lead: Lead) => void;
  updateLead: (lead: Lead) => void;
  deleteLead: (id: string) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Initialize state with Mock Data
  const [complaints, setComplaints] = useState<Complaint[]>(MOCK_COMPLAINTS);
  const [units, setUnits] = useState<UnitData[]>(MOCK_UNITS);
  const [invoices, setInvoices] = useState<Invoice[]>(MOCK_INVOICES);
  const [expenses, setExpenses] = useState<ClusterExpense[]>(MOCK_CLUSTER_EXPENSES);
  const [clusters, setClusters] = useState<Cluster[]>(MOCK_CLUSTERS);
  const [vendors, setVendors] = useState<Vendor[]>(MOCK_VENDORS);
  const [leads, setLeads] = useState<Lead[]>(MOCK_LEADS);

  // Complaints
  const addComplaint = (newComplaint: Complaint) => {
    setComplaints(prev => [newComplaint, ...prev]);
  };

  const updateComplaintStatus = (id: string, status: ComplaintStatus) => {
    setComplaints(prev => prev.map(c => 
      c.id === id ? { ...c, status: status } : c
    ));
  };

  // Units
  const addUnit = (newUnit: UnitData) => {
    setUnits(prev => [newUnit, ...prev]);
  };

  const updateUnit = (updatedUnit: UnitData) => {
    setUnits(prev => prev.map(u => u.id === updatedUnit.id ? updatedUnit : u));
  };

  const deleteUnit = (id: string) => {
    setUnits(prev => prev.filter(u => u.id !== id));
  };

  // Invoices
  const payInvoice = (id: string) => {
    setInvoices(prev => prev.map(inv => 
      inv.id === id ? { ...inv, status: InvoiceStatus.PAID } : inv
    ));
  };

  const addInvoice = (newInvoice: Invoice) => {
    setInvoices(prev => [newInvoice, ...prev]);
  };

  const updateInvoice = (updatedInvoice: Invoice) => {
    setInvoices(prev => prev.map(inv => inv.id === updatedInvoice.id ? updatedInvoice : inv));
  };

  const deleteInvoice = (id: string) => {
    setInvoices(prev => prev.filter(inv => inv.id !== id));
  };

  // Expenses
  const addExpense = (newExpense: ClusterExpense) => {
    setExpenses(prev => [newExpense, ...prev]);
  };

  const updateExpense = (updatedExpense: ClusterExpense) => {
    setExpenses(prev => prev.map(exp => exp.id === updatedExpense.id ? updatedExpense : exp));
  };

  const deleteExpense = (id: string) => {
    setExpenses(prev => prev.filter(exp => exp.id !== id));
  };

  // Clusters
  const addCluster = (newCluster: Cluster) => {
    setClusters(prev => [...prev, newCluster]);
  };

  const updateCluster = (updatedCluster: Cluster) => {
    setClusters(prev => prev.map(c => 
      c.id === updatedCluster.id ? updatedCluster : c
    ));
  };

  const deleteCluster = (id: string) => {
    setClusters(prev => prev.filter(c => c.id !== id));
  };

  // Vendors
  const addVendor = (newVendor: Vendor) => {
    setVendors(prev => [...prev, newVendor]);
  };

  const updateVendor = (updatedVendor: Vendor) => {
    setVendors(prev => prev.map(v => v.id === updatedVendor.id ? updatedVendor : v));
  };

  const deleteVendor = (id: string) => {
    setVendors(prev => prev.filter(v => v.id !== id));
  };

  // Leads (Marketing)
  const addLead = (newLead: Lead) => {
    setLeads(prev => [newLead, ...prev]);
  }

  const updateLead = (updatedLead: Lead) => {
    setLeads(prev => prev.map(l => l.id === updatedLead.id ? updatedLead : l));
  }

  const deleteLead = (id: string) => {
    setLeads(prev => prev.filter(l => l.id !== id));
  }

  return (
    <DataContext.Provider value={{
      complaints,
      units,
      invoices,
      expenses,
      clusters,
      vendors,
      leads,
      addComplaint,
      updateComplaintStatus,
      addUnit,
      updateUnit,
      deleteUnit,
      payInvoice,
      addInvoice,
      updateInvoice,
      deleteInvoice,
      addExpense,
      updateExpense,
      deleteExpense,
      addCluster,
      updateCluster,
      deleteCluster,
      addVendor,
      updateVendor,
      deleteVendor,
      addLead,
      updateLead,
      deleteLead
    }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};