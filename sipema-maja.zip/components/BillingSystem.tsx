import React, { useState } from 'react';
import { MOCK_USER } from '../constants';
import { InvoiceStatus, Invoice } from '../types';
import { Download, CreditCard, Shield, Zap, Wrench, Trash2, MoreHorizontal, TrendingUp, TrendingDown, DollarSign, QrCode, Store, CheckCircle, X } from 'lucide-react';
import { useData } from '../DataContext';

export const BillingSystem: React.FC = () => {
  const { invoices, payInvoice, expenses } = useData(); // Use Context
  const [activeTab, setActiveTab] = useState<'personal' | 'cluster'>('personal');
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'va' | 'qris' | 'retail'>('va');
  const [isProcessing, setIsProcessing] = useState(false);

  // Helper to format currency
  const formatRupiah = (amount: number) => {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(amount);
  };

  // Calculations for Cluster Financials
  const totalExpenses = expenses.reduce((acc, curr) => acc + curr.amount, 0);
  const totalIncome = 25000000; 
  const balance = totalIncome - totalExpenses;

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Security': return <Shield size={18} />;
      case 'Kebersihan': return <Trash2 size={18} />;
      case 'Listrik': return <Zap size={18} />;
      case 'Perbaikan': return <Wrench size={18} />;
      default: return <MoreHorizontal size={18} />;
    }
  };

  const handlePayClick = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
    setIsPaymentModalOpen(true);
  };

  const simulatePayment = () => {
    setIsProcessing(true);
    setTimeout(() => {
      if (selectedInvoice) {
        // Execute Payment in Global State
        payInvoice(selectedInvoice.id);
        
        setIsProcessing(false);
        setIsPaymentModalOpen(false);
        alert("Pembayaran Berhasil! Status tagihan otomatis diperbarui.");
      }
    }, 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header & Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold text-gray-800">Keuangan & Tagihan</h2>
        
        <div className="flex bg-gray-200 p-1 rounded-lg self-start sm:self-auto">
          <button
            onClick={() => setActiveTab('personal')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
              activeTab === 'personal' 
                ? 'bg-white text-emerald-700 shadow-sm' 
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Tagihan Saya
          </button>
          <button
            onClick={() => setActiveTab('cluster')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
              activeTab === 'cluster' 
                ? 'bg-white text-emerald-700 shadow-sm' 
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Transparansi Cluster
          </button>
        </div>
      </div>

      {/* Content Area */}
      {activeTab === 'personal' ? (
        <div className="space-y-6 animate-fadeIn">
          {/* Active Invoices */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {invoices.map((inv) => {
              const isPaid = inv.status === InvoiceStatus.PAID;
              const isOverdue = inv.status === InvoiceStatus.OVERDUE;

              return (
                <div key={inv.id} className={`bg-white rounded-xl shadow-sm border p-6 flex flex-col justify-between relative overflow-hidden transition-all hover:shadow-md ${isOverdue && !isPaid ? 'border-red-200 ring-1 ring-red-100' : 'border-gray-100'}`}>
                  {isOverdue && !isPaid && (
                    <div className="absolute top-0 right-0 bg-red-500 text-white text-[10px] px-3 py-1 rounded-bl-lg font-bold shadow-sm">
                      TERLAMBAT
                    </div>
                  )}
                  {isPaid && (
                    <div className="absolute top-0 right-0 bg-emerald-500 text-white text-[10px] px-3 py-1 rounded-bl-lg font-bold shadow-sm flex items-center gap-1">
                      LUNAS <CheckCircle size={10} />
                    </div>
                  )}
                  
                  <div>
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">IPL Periode</p>
                        <h3 className="text-xl font-bold text-gray-800 mt-0.5">{inv.month} {inv.year}</h3>
                      </div>
                      <div className={`h-10 w-10 rounded-full flex items-center justify-center ${isPaid ? 'bg-emerald-100 text-emerald-600' : 'bg-gray-100 text-gray-500'}`}>
                        <CreditCard size={20} />
                      </div>
                    </div>

                    <div className="space-y-3 mb-6">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">Jenis Tagihan</span>
                        <span className="font-medium text-gray-700">{inv.category}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">Jatuh Tempo</span>
                        <span className={`font-medium ${isOverdue && !isPaid ? 'text-red-600' : 'text-gray-700'}`}>{inv.dueDate}</span>
                      </div>
                      <div className="flex justify-between text-base font-bold pt-3 border-t border-dashed border-gray-200">
                        <span className="text-gray-800">Total</span>
                        <span className="text-emerald-600">{formatRupiah(inv.amount)}</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    {isPaid ? (
                      <button className="w-full bg-gray-50 text-gray-400 py-2.5 rounded-lg font-medium hover:bg-gray-100 hover:text-gray-600 transition-colors flex items-center justify-center gap-2 text-sm border border-gray-200">
                        <Download size={16} />
                        Download Kwitansi
                      </button>
                    ) : (
                      <button 
                        onClick={() => handlePayClick(inv)}
                        className="w-full bg-slate-900 text-white py-2.5 rounded-lg font-medium hover:bg-slate-800 transition-colors shadow-lg shadow-slate-200 text-sm flex items-center justify-center gap-2"
                      >
                        Bayar Sekarang <CreditCard size={16} />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="bg-blue-50 border border-blue-100 rounded-xl p-5 flex gap-4 items-start">
            <div className="p-2 bg-blue-100 rounded-lg text-blue-600 shrink-0">
              <Zap size={20} />
            </div>
            <div>
              <h4 className="font-bold text-blue-800 text-sm">Auto-Generated Invoices</h4>
              <p className="text-sm text-blue-700 mt-1 leading-relaxed">
                Tagihan IPL digenerate otomatis setiap tanggal <strong>1 awal bulan</strong>. Sistem pembayaran terintegrasi dengan Payment Gateway (Midtrans), status tagihan akan berubah LUNAS secara realtime setelah pembayaran terverifikasi.
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6 animate-fadeIn">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
             <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-100">
               <div className="flex items-center gap-3 mb-2">
                 <div className="p-2 bg-emerald-100 text-emerald-600 rounded-lg">
                   <TrendingUp size={20} />
                 </div>
                 <span className="text-sm text-gray-500 font-medium">Pemasukan (Bulan Ini)</span>
               </div>
               <h3 className="text-2xl font-bold text-gray-800">{formatRupiah(totalIncome)}</h3>
               <p className="text-xs text-gray-400 mt-1">Dari 98 unit yang membayar</p>
             </div>

             <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-100">
               <div className="flex items-center gap-3 mb-2">
                 <div className="p-2 bg-rose-100 text-rose-600 rounded-lg">
                   <TrendingDown size={20} />
                 </div>
                 <span className="text-sm text-gray-500 font-medium">Pengeluaran (Bulan Ini)</span>
               </div>
               <h3 className="text-2xl font-bold text-gray-800">{formatRupiah(totalExpenses)}</h3>
               <p className="text-xs text-gray-400 mt-1">Operasional & Perbaikan</p>
             </div>

             <div className="bg-gradient-to-br from-slate-800 to-slate-900 text-white p-5 rounded-xl shadow-md">
               <div className="flex items-center gap-3 mb-2">
                 <div className="p-2 bg-white/10 text-emerald-400 rounded-lg">
                   <DollarSign size={20} />
                 </div>
                 <span className="text-sm text-gray-300 font-medium">Saldo Kas Cluster {MOCK_USER.cluster}</span>
               </div>
               <h3 className="text-2xl font-bold">{formatRupiah(balance)}</h3>
               <div className="flex items-center gap-2 mt-2">
                 <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                 <p className="text-xs text-gray-400">Realtime Update</p>
               </div>
             </div>
          </div>

          {/* Detailed Expense List */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
              <h3 className="font-bold text-gray-800">Rincian Pengeluaran Cluster</h3>
              <button className="text-sm text-emerald-600 hover:text-emerald-700 font-medium flex items-center gap-1">
                <Download size={14} /> Laporan PDF
              </button>
            </div>
            
            <div className="divide-y divide-gray-100">
              {expenses.map((expense) => (
                <div key={expense.id} className="p-4 sm:px-6 hover:bg-gray-50 transition-colors flex items-center justify-between group">
                  <div className="flex items-start gap-4">
                    <div className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 group-hover:bg-emerald-100 group-hover:text-emerald-600 transition-colors shrink-0">
                      {getCategoryIcon(expense.category)}
                    </div>
                    <div>
                      <p className="font-bold text-gray-800 text-sm sm:text-base">{expense.description}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[10px] font-bold uppercase tracking-wide px-2 py-0.5 bg-gray-100 text-gray-500 rounded-full">
                          {expense.category}
                        </span>
                        <span className="text-xs text-gray-400">{expense.date}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-gray-800 text-sm sm:text-base">
                      - {formatRupiah(expense.amount)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Payment Gateway Simulation Modal */}
      {isPaymentModalOpen && selectedInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fadeIn">
          <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl scale-100">
            <div className="bg-slate-50 border-b border-gray-200 p-4 flex justify-between items-center">
              <h3 className="font-bold text-gray-800">Pembayaran Tagihan</h3>
              <button onClick={() => setIsPaymentModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                <X size={20} />
              </button>
            </div>

            <div className="p-6">
              <div className="flex justify-between items-end mb-6">
                <div>
                  <p className="text-sm text-gray-500">Total Pembayaran</p>
                  <h2 className="text-3xl font-bold text-gray-900 mt-1">{formatRupiah(selectedInvoice.amount)}</h2>
                </div>
                <div className="text-right">
                   <p className="text-xs font-bold bg-blue-100 text-blue-700 px-2 py-1 rounded">{selectedInvoice.month} {selectedInvoice.year}</p>
                </div>
              </div>

              {/* Payment Methods Tabs */}
              <div className="grid grid-cols-3 gap-2 mb-6 p-1 bg-gray-100 rounded-lg">
                <button 
                  onClick={() => setPaymentMethod('va')}
                  className={`py-2 text-xs font-bold rounded-md transition-all ${paymentMethod === 'va' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  Virtual Account
                </button>
                <button 
                  onClick={() => setPaymentMethod('qris')}
                  className={`py-2 text-xs font-bold rounded-md transition-all ${paymentMethod === 'qris' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  QRIS
                </button>
                <button 
                  onClick={() => setPaymentMethod('retail')}
                  className={`py-2 text-xs font-bold rounded-md transition-all ${paymentMethod === 'retail' ? 'bg-white text-gray-800 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  Retail / Minimarket
                </button>
              </div>

              {/* Method Content */}
              <div className="min-h-[120px] mb-6">
                {paymentMethod === 'va' && (
                  <div className="space-y-3">
                    <div className="p-3 border rounded-lg flex items-center justify-between hover:border-emerald-500 cursor-pointer">
                      <div className="flex items-center gap-3">
                         <div className="w-8 h-8 bg-blue-800 rounded flex items-center justify-center text-white text-[10px] font-bold">BCA</div>
                         <span className="font-medium text-sm">BCA Virtual Account</span>
                      </div>
                      <div className="h-4 w-4 rounded-full border border-gray-300"></div>
                    </div>
                    <div className="p-3 border rounded-lg flex items-center justify-between hover:border-emerald-500 cursor-pointer">
                      <div className="flex items-center gap-3">
                         <div className="w-8 h-8 bg-blue-400 rounded flex items-center justify-center text-white text-[10px] font-bold">MDR</div>
                         <span className="font-medium text-sm">Mandiri Bill</span>
                      </div>
                      <div className="h-4 w-4 rounded-full border border-gray-300"></div>
                    </div>
                  </div>
                )}

                {paymentMethod === 'qris' && (
                  <div className="flex flex-col items-center justify-center text-center">
                    <QrCode size={80} className="text-gray-800 mb-2" />
                    <p className="text-xs text-gray-500">Scan menggunakan GoPay, OVO, Dana, ShopeePay</p>
                  </div>
                )}

                {paymentMethod === 'retail' && (
                   <div className="space-y-3">
                    <div className="p-3 border rounded-lg flex items-center justify-between hover:border-emerald-500 cursor-pointer">
                      <div className="flex items-center gap-3">
                         <Store size={20} className="text-red-600"/>
                         <span className="font-medium text-sm">Alfamart / Alfamidi</span>
                      </div>
                    </div>
                     <div className="p-3 border rounded-lg flex items-center justify-between hover:border-emerald-500 cursor-pointer">
                      <div className="flex items-center gap-3">
                         <Store size={20} className="text-blue-600"/>
                         <span className="font-medium text-sm">Indomaret</span>
                      </div>
                    </div>
                   </div>
                )}
              </div>

              <button 
                onClick={simulatePayment}
                disabled={isProcessing}
                className="w-full bg-emerald-600 text-white py-3 rounded-xl font-bold hover:bg-emerald-700 transition-all flex items-center justify-center gap-2"
              >
                {isProcessing ? 'Memproses...' : 'Konfirmasi Pembayaran'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};