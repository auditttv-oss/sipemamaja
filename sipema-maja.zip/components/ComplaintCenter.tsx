import React, { useState, useEffect } from 'react';
import { Camera, AlertCircle, Wrench, ThumbsUp, Clock, CheckCircle, MapPin, XCircle, DollarSign, Activity } from 'lucide-react';
import { MOCK_USER } from '../constants';
import { ComplaintCategory, ComplaintStatus } from '../types';
import { useData } from '../DataContext';

export const ComplaintCenter: React.FC = () => {
  const { complaints, addComplaint } = useData(); // Use Context
  const [activeTab, setActiveTab] = useState<'form' | 'list'>('form');
  const [category, setCategory] = useState<ComplaintCategory>(ComplaintCategory.RETENSI);
  const [subCategory, setSubCategory] = useState('');
  const [description, setDescription] = useState('');
  const [warrantyStatus, setWarrantyStatus] = useState<'active' | 'expired'>('active');
  const [daysRemaining, setDaysRemaining] = useState(0);

  // Logic to calculate Retensi Validity based on BAST
  useEffect(() => {
    if (MOCK_USER.bastDate) {
      const bast = new Date(MOCK_USER.bastDate);
      const today = new Date();
      // 90 days warranty logic
      const expiryDate = new Date(bast);
      expiryDate.setDate(bast.getDate() + 90);
      
      const diffTime = expiryDate.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      setDaysRemaining(diffDays);
      setWarrantyStatus(diffDays > 0 ? 'active' : 'expired');
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Create new complaint object
    const newComplaint = {
      id: `C-${Date.now().toString().slice(-4)}`, // Generate simple ID
      userId: MOCK_USER.id,
      category: category,
      subCategory: subCategory || (category === 'Retensi' ? 'Kerusakan Umum' : 'Fasilitas Umum'),
      description: description,
      status: ComplaintStatus.PENDING,
      isWarranty: category === ComplaintCategory.RETENSI && warrantyStatus === 'active',
      createdAt: new Date().toISOString().split('T')[0],
      upvotes: 0
    };

    // Add to Global Context
    addComplaint(newComplaint);

    const type = category === ComplaintCategory.RETENSI 
      ? (warrantyStatus === 'active' ? 'Klaim Garansi' : 'Order Jasa Berbayar')
      : 'Laporan Fasum';
      
    alert(`Laporan "${type}" berhasil dikirim! \nSistem akan meneruskan ke ${warrantyStatus === 'active' && category === 'Retensi' ? 'Tim Developer (Prioritas)' : 'Teknisi Pengelola'}.`);
    
    // Reset form
    setDescription('');
    setSubCategory('');
    setActiveTab('list');
  };

  const getStatusColor = (status: ComplaintStatus) => {
    switch (status) {
      case ComplaintStatus.PENDING: return 'bg-gray-100 text-gray-600 border-gray-200';
      case ComplaintStatus.PROSES: return 'bg-amber-50 text-amber-700 border-amber-200';
      case ComplaintStatus.SELESAI: return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case ComplaintStatus.DITOLAK: return 'bg-red-50 text-red-700 border-red-200';
      default: return 'bg-gray-100';
    }
  };

  // Helper for Stepper Visualization
  const renderTrackingSteps = (status: ComplaintStatus) => {
    const steps = [
      { id: 'sent', label: 'Terkirim', active: true },
      { id: 'process', label: 'Dikerjakan', active: status === ComplaintStatus.PROSES || status === ComplaintStatus.SELESAI },
      { id: 'done', label: 'Selesai', active: status === ComplaintStatus.SELESAI },
    ];

    return (
      <div className="flex items-center justify-between w-full mt-4 relative">
        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-0.5 bg-gray-200 -z-10"></div>
        {steps.map((step) => (
          <div key={step.id} className="flex flex-col items-center bg-white px-2">
            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold border-2 transition-colors ${
              step.active 
                ? 'bg-emerald-600 border-emerald-600 text-white' 
                : 'bg-white border-gray-300 text-gray-400'
            }`}>
              {step.active && <CheckCircle size={12} />}
            </div>
            <span className={`text-[10px] mt-1 font-medium ${step.active ? 'text-emerald-700' : 'text-gray-400'}`}>
              {step.label}
            </span>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
           <h2 className="text-2xl font-bold text-gray-800">Pusat Aduan</h2>
           <p className="text-gray-500 text-sm">Layanan purna jual & pemeliharaan lingkungan</p>
        </div>
        
        <div className="bg-white p-1 rounded-lg border border-gray-200 flex shadow-sm">
          <button
            onClick={() => setActiveTab('form')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === 'form' ? 'bg-emerald-50 text-emerald-700 shadow-sm' : 'text-gray-600 hover:bg-gray-50'}`}
          >
            Buat Laporan Baru
          </button>
          <button
            onClick={() => setActiveTab('list')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === 'list' ? 'bg-emerald-50 text-emerald-700 shadow-sm' : 'text-gray-600 hover:bg-gray-50'}`}
          >
            Tracking Tiket
          </button>
        </div>
      </div>

      {activeTab === 'form' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fadeIn">
          <div className="lg:col-span-2 space-y-6">
            <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
              {/* Category Selector */}
              <div className="mb-8">
                <label className="block text-sm font-bold text-gray-700 mb-3">Pilih Jenis Masalah</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div 
                    onClick={() => setCategory(ComplaintCategory.RETENSI)}
                    className={`cursor-pointer border-2 rounded-xl p-5 flex items-start gap-4 transition-all relative overflow-hidden ${category === ComplaintCategory.RETENSI ? 'border-blue-500 bg-blue-50/50' : 'border-gray-100 hover:border-blue-200'}`}
                  >
                    <div className={`p-3 rounded-full ${category === ComplaintCategory.RETENSI ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-500'}`}>
                       <Wrench size={24} />
                    </div>
                    <div>
                      <h4 className={`font-bold ${category === ComplaintCategory.RETENSI ? 'text-blue-700' : 'text-gray-700'}`}>Kerusakan Unit</h4>
                      <p className="text-xs text-gray-500 mt-1">Dinding retak, atap bocor, lantai.</p>
                    </div>
                    {category === ComplaintCategory.RETENSI && <div className="absolute top-0 right-0 w-4 h-4 bg-blue-500 rounded-bl-lg"></div>}
                  </div>

                  <div 
                    onClick={() => setCategory(ComplaintCategory.FASUM)}
                    className={`cursor-pointer border-2 rounded-xl p-5 flex items-start gap-4 transition-all relative overflow-hidden ${category === ComplaintCategory.FASUM ? 'border-emerald-500 bg-emerald-50/50' : 'border-gray-100 hover:border-emerald-200'}`}
                  >
                    <div className={`p-3 rounded-full ${category === ComplaintCategory.FASUM ? 'bg-emerald-100 text-emerald-600' : 'bg-gray-100 text-gray-500'}`}>
                       <MapPin size={24} />
                    </div>
                    <div>
                      <h4 className={`font-bold ${category === ComplaintCategory.FASUM ? 'text-emerald-700' : 'text-gray-700'}`}>Fasilitas Umum</h4>
                      <p className="text-xs text-gray-500 mt-1">Jalan, PJU, Sampah, Keamanan.</p>
                    </div>
                    {category === ComplaintCategory.FASUM && <div className="absolute top-0 right-0 w-4 h-4 bg-emerald-500 rounded-bl-lg"></div>}
                  </div>
                </div>
              </div>

              {/* Dynamic Logic Box */}
              {category === ComplaintCategory.RETENSI && (
                <div className={`mb-6 p-5 rounded-xl border flex gap-4 ${warrantyStatus === 'active' ? 'bg-emerald-50 border-emerald-200' : 'bg-amber-50 border-amber-200'}`}>
                  <div className={`shrink-0 p-2 rounded-full ${warrantyStatus === 'active' ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'}`}>
                    {warrantyStatus === 'active' ? <CheckCircle size={24} /> : <DollarSign size={24} />}
                  </div>
                  <div>
                    <h4 className={`font-bold text-sm ${warrantyStatus === 'active' ? 'text-emerald-800' : 'text-amber-800'}`}>
                      {warrantyStatus === 'active' ? 'Garansi Developer Aktif (Prioritas)' : 'Masa Garansi Habis (> 90 Hari)'}
                    </h4>
                    <p className={`text-sm mt-1 leading-relaxed ${warrantyStatus === 'active' ? 'text-emerald-700' : 'text-amber-700'}`}>
                      {warrantyStatus === 'active' 
                        ? `Unit Anda masih dalam masa retensi (${daysRemaining} hari tersisa). Perbaikan akan ditanggung developer sepenuhnya (Gratis).` 
                        : "Laporan ini akan masuk kategori 'Jasa Perbaikan Berbayar'. Teknisi akan melakukan survei dan memberikan estimasi biaya kepada Anda."}
                    </p>
                  </div>
                </div>
              )}

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Judul Masalah</label>
                <input 
                  type="text"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-shadow text-sm mb-4"
                  placeholder="Contoh: Atap Bocor di Kamar Tidur"
                  value={subCategory}
                  onChange={(e) => setSubCategory(e.target.value)}
                  required
                />

                <label className="block text-sm font-medium text-gray-700 mb-2">Deskripsi Detail</label>
                <textarea 
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-shadow text-sm"
                  placeholder="Ceritakan kronologi kerusakan..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  required
                />
              </div>

              <div className="mb-8">
                <label className="block text-sm font-medium text-gray-700 mb-2">Foto Bukti (Wajib)</label>
                <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 flex flex-col items-center justify-center text-gray-500 hover:bg-gray-50 hover:border-emerald-400 cursor-pointer transition-all">
                  <div className="bg-gray-100 p-3 rounded-full mb-3">
                    <Camera size={24} className="text-gray-600" />
                  </div>
                  <span className="text-sm font-medium text-gray-700">Klik untuk upload foto</span>
                  <span className="text-xs text-gray-400 mt-1">Maks. 5MB (JPG/PNG)</span>
                </div>
              </div>

              <button type="submit" className="w-full bg-slate-900 text-white py-3.5 rounded-xl font-bold hover:bg-slate-800 transition-colors shadow-lg shadow-slate-200 flex items-center justify-center gap-2">
                {category === 'Retensi' && warrantyStatus === 'active' ? (
                   <><Activity size={18} /> Ajukan Klaim Garansi</>
                ) : (
                   <><Clock size={18} /> Kirim Laporan</>
                )}
              </button>
            </form>
          </div>

          <div className="lg:col-span-1">
             <div className="sticky top-6 space-y-4">
              <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm">
                 <h3 className="font-bold text-gray-800 mb-3">Data Unit Anda</h3>
                 <div className="space-y-3 text-sm">
                    <div className="flex justify-between py-2 border-b border-gray-50">
                       <span className="text-gray-500">Unit</span>
                       <span className="font-medium">{MOCK_USER.unit}</span>
                    </div>
                    <div className="flex justify-between py-2 border-b border-gray-50">
                       <span className="text-gray-500">Cluster</span>
                       <span className="font-medium">{MOCK_USER.cluster}</span>
                    </div>
                    <div className="flex justify-between py-2">
                       <span className="text-gray-500">Tgl BAST</span>
                       <span className="font-medium">{MOCK_USER.bastDate}</span>
                    </div>
                 </div>
              </div>

              <div className="bg-indigo-600 text-white p-6 rounded-xl shadow-lg shadow-indigo-200">
                <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                  <AlertCircle size={20} /> Info Penting
                </h3>
                <ul className="space-y-3 text-indigo-100 text-sm">
                  <li className="flex gap-3 items-start">
                    <div className="w-1.5 h-1.5 rounded-full bg-white mt-2 shrink-0"></div>
                    <span>Garansi struktural berlaku <strong>3 bulan</strong> sejak serah terima kunci.</span>
                  </li>
                  <li className="flex gap-3 items-start">
                    <div className="w-1.5 h-1.5 rounded-full bg-white mt-2 shrink-0"></div>
                    <span>Kerusakan akibat renovasi pribadi di luar tanggung jawab developer.</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'list' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-fadeIn">
          {complaints.length > 0 ? complaints.map((complaint) => (
            <div key={complaint.id} className="bg-white p-5 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow group">
              <div className="flex items-start justify-between mb-3">
                 <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold ${complaint.category === ComplaintCategory.RETENSI ? 'bg-blue-50 text-blue-700' : 'bg-purple-50 text-purple-700'}`}>
                    {complaint.category === ComplaintCategory.RETENSI ? <Wrench size={12} /> : <MapPin size={12} />}
                    {complaint.category}
                 </span>
                 <span className={`px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusColor(complaint.status)}`}>
                   {complaint.status}
                 </span>
              </div>
              
              <div className="flex gap-4">
                 <div className="h-20 w-20 rounded-lg bg-gray-100 shrink-0 overflow-hidden">
                   <img src={`https://picsum.photos/seed/${complaint.id}/200`} alt="Evidence" className="h-full w-full object-cover group-hover:scale-110 transition-transform duration-500" />
                 </div>
                 <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-gray-800 truncate">{complaint.subCategory}</h3>
                    <p className="text-gray-500 text-xs mt-1 line-clamp-2">{complaint.description}</p>
                    <div className="flex items-center gap-2 mt-2 text-xs text-gray-400">
                       <Clock size={12} /> {complaint.createdAt}
                    </div>
                 </div>
              </div>

              {/* Step Tracking Visualization */}
              {complaint.category === ComplaintCategory.RETENSI && (
                 renderTrackingSteps(complaint.status)
              )}
              
              {complaint.category === ComplaintCategory.FASUM && (
                 <div className="mt-4 pt-3 border-t border-gray-50 flex justify-between items-center">
                    <span className="text-xs text-gray-400">Masalah Fasilitas Umum</span>
                    <button className="flex items-center gap-1 text-emerald-600 text-xs font-bold hover:bg-emerald-50 px-2 py-1 rounded transition-colors">
                      <ThumbsUp size={12} /> {complaint.upvotes} Upvotes
                    </button>
                 </div>
              )}
            </div>
          )) : (
            <div className="col-span-2 text-center py-10 text-gray-500 bg-white rounded-xl">
              Belum ada riwayat laporan.
            </div>
          )}
        </div>
      )}
    </div>
  );
};