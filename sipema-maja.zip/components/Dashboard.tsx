import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Wallet, FileWarning, CheckCircle, AlertTriangle, ArrowRight } from 'lucide-react';
import { CHART_DATA, MOCK_INVOICES, MOCK_USER } from '../constants';

interface DashboardProps {
  onViewChange: (view: any) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onViewChange }) => {
  const unpaidCount = MOCK_INVOICES.filter(i => i.status !== 'Paid').length;
  
  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h2 className="text-2xl font-bold text-gray-800">Selamat Pagi, {MOCK_USER.name}</h2>
        <p className="text-gray-500 mt-1">Cluster {MOCK_USER.cluster}, Unit {MOCK_USER.unit}</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div 
          onClick={() => onViewChange('billing')}
          className="bg-white p-5 rounded-xl shadow-sm border border-gray-100 cursor-pointer hover:shadow-md transition-shadow"
        >
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-gray-500">Tagihan Belum Lunas</p>
              <h3 className="text-2xl font-bold text-gray-800 mt-1">{unpaidCount}</h3>
            </div>
            <div className="p-2 bg-rose-100 rounded-lg text-rose-600">
              <Wallet size={20} />
            </div>
          </div>
          <div className="mt-4 text-xs text-rose-600 font-medium flex items-center">
            Segera selesaikan pembayaran <ArrowRight size={12} className="ml-1"/>
          </div>
        </div>

        <div 
           onClick={() => onViewChange('complaints')}
           className="bg-white p-5 rounded-xl shadow-sm border border-gray-100 cursor-pointer hover:shadow-md transition-shadow"
        >
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-gray-500">Komplain Aktif</p>
              <h3 className="text-2xl font-bold text-gray-800 mt-1">1</h3>
            </div>
            <div className="p-2 bg-amber-100 rounded-lg text-amber-600">
              <FileWarning size={20} />
            </div>
          </div>
          <div className="mt-4 text-xs text-amber-600 font-medium">
            Sedang dalam proses perbaikan
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-100">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-gray-500">Status Retensi</p>
              <h3 className="text-xl font-bold text-gray-800 mt-1">Aktif</h3>
            </div>
            <div className="p-2 bg-emerald-100 rounded-lg text-emerald-600">
              <CheckCircle size={20} />
            </div>
          </div>
          <div className="mt-4 text-xs text-emerald-600 font-medium">
            Masa garansi berakhir 15 Feb 2024
          </div>
        </div>

        <div 
          onClick={() => onViewChange('panic')}
          className="bg-gradient-to-br from-red-500 to-rose-600 p-5 rounded-xl shadow-md cursor-pointer hover:shadow-lg transition-shadow text-white"
        >
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-white/90">Darurat?</p>
              <h3 className="text-xl font-bold mt-1">Panic Button</h3>
            </div>
            <div className="p-2 bg-white/20 rounded-lg">
              <AlertTriangle size={20} />
            </div>
          </div>
          <div className="mt-4 text-xs text-white/90 font-medium">
            Tekan untuk panggil keamanan
          </div>
        </div>
      </div>

      {/* Financial Chart (Admin View Context) */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-bold text-gray-800">Transparansi Keuangan Cluster {MOCK_USER.cluster}</h3>
          <span className="text-sm text-gray-500">Tahun 2023</span>
        </div>
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={CHART_DATA}
              margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#6B7280'}} />
              <YAxis axisLine={false} tickLine={false} tick={{fill: '#6B7280'}} />
              <Tooltip 
                cursor={{fill: '#F3F4F6'}}
                contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
              />
              <Bar dataKey="income" name="Pemasukan (IPL)" fill="#10B981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="expense" name="Pengeluaran" fill="#F43F5E" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};